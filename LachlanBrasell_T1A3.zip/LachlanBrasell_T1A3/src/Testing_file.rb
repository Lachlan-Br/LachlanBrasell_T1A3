#No time to finish ------------------------------------------------------------------------



It “allow user to change colour of said coding and continue to main screen”
	do…………

It “Check for user has characters as a name and welcome message appeared properly” 
	Do ……………….

It “ Get to menu and able to select a “add username and password / create username and password / view usernames and passwords”
	Do…………

If - selected view - put a loading screen of “please hide your screen for the viewing of sensitive data”
	do………………

It (a) “Confirms you’d like to “add” your own and not generate new usernames and passwords” 
	Do……….

It (a2) “Person enters a username (of no less than 5) and password (no less than 4) whilst giving some facts on time to crack a password and how long etc. a quick readme.”
	do…………

It (a3) “confirms new data has been recorded - playback to user and confirm correct”
	do………….

It (b) “Confirm selection and quote acceptance of “this is to generate new passwords and usernames and save them” - New passwords saved as date and or title. - confirms selected of 8-12-24-32 is available”
	Do………….

It (b2) “allow choice of password / username presented and allow user to choose out of many if option is chosen.”
	do………

It (b3) “confirm selection of creation of password or username or both, save them as date or allow input for user.”
	Do………

it(b4) “give an end message and continue back to main page to ask if there’s anything else they need”
	do…………

It (c)  “transfer user to the list of currently saved or generated passwords, give a quick demo or list a “example” piece for them to see”
	Do……….

It (c2) “Allow user to view all and select back to main menu.”
	do……….




        tests - code testing / error handling
- Passwords have Capitals etc to make sure they're safe
- Certain lengths
- Profile names etc
- Many checks throughout the process of saving usernames / passwords and connection to users
- colour choice
