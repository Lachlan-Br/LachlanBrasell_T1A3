#!/bin/bashls

echo "Preparing your password generator and bank...."

rm Gemfile.lock

gem install bundler

clear

ruby index.rb 
